package com.csv.vpn.model;

import android.view.View;

public interface OnUpdateLayout {
	void updateLayout(View view);
}
