Thanks for downloading this theme!

Theme Name: Bethany
Theme URL: https://bootstrapmade.com/bethany-free-onepage-bootstrap-theme/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com